#include <iostream>
#include <cstring>
#include <vector>
#include <string>
#include <fstream>
#include <cmath>
#include <map>
#include <unordered_map>
#include <algorithm>

using namespace std;

int countSubstring(const std::string& str, const std::string& sub)
{
	if (sub.length() == 0) return 0;
	int count = 0;
	for (size_t offset = str.find(sub); offset != std::string::npos;
		offset = str.find(sub, offset + sub.length()))
	{
		++count;
	}
	return count;
}

int getDecFromHex(char ch)
{
	switch (ch)
	{
	case 'a':
		return 10;
	case 'b':
		return 11;
	case 'c':
		return 12;
	case 'd':
		return 13;
	case 'e':
		return 14;
	case 'f':
		return 15;
	default:
		return ch - '0';
	}
}

map<int, int> dnas;

int main() {

	string input;
	cin >> input;

	// ifstream fileInput("test1.txt");
	// getline(fileInput, input);

	int length = input.length() - 1;

	string currDNA;
	int position = 0;
	int numberOfOccurences = 0;

	for (size_t i = 0; i < length; i += 5)
	{
		int currDNA = getDecFromHex(input[i]) * pow(16, 4)
					+ getDecFromHex(input[i + 1]) * pow(16, 3)
					+ getDecFromHex(input[i + 2]) * pow(16, 2)
					+ getDecFromHex(input[i + 3]) * pow(16, 1)
					+ getDecFromHex(input[i + 4]) * pow(16, 0);
		dnas[currDNA]++;
	}

	auto foundPtr = find_if(dnas.begin(), dnas.end(), [](const pair<int, int>& mp) { return mp.second == 1; });
	cout << hex << (*foundPtr).first << endl;

	/*while (true)
	{
		currDNA = input.substr(position, 5);

		numberOfOccurences = countSubstring(input, currDNA);
		if (numberOfOccurences == 1)
		{
			cout << currDNA << endl;
			break;
		}

		position += 5;
	}*/

	return 0;
}