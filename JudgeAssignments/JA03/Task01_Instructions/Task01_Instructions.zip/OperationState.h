#pragma once

enum class OperationState
{
	Insert,
	Sum,
	Subtract,
	Concat,
	Discard
};